import base64
import json
import logging
import boto3
import os
import hashlib
import decimal

TABLE_NAME = os.environ['TABLE_NAME']
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.info("Loading function")

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(TABLE_NAME)
logger.info('Established client connection.')

def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))
    logger.info(event)
    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        logger.info("Decoded payload: " + payload)
        
        # Convert payload to JSON object
        payloadJson = json.loads(payload)
        # Create hash from sensor uid and timestamp
        sensorHash = hashlib.md5()
        try:
            sensorHash.update(payloadJson['uid'].encode('utf-8'))
            sensorHash.update(payloadJson['timestamp'].encode('utf-8'))
        except KeyError:
            logger.info("Invalid payload: Missing attributes 'uid' and 'timestamp'")
            continue
        # Create dict representing table item
        for key,value in payloadJson.items():
            if type(payloadJson[key]) is int or type(payloadJson[key]) is float:
                payloadJson[key] = decimal.Decimal(str(payloadJson[key]))
        tableItem = dict()
        tableItem['SensorHash'] = sensorHash.hexdigest()
        tableItem.update(payloadJson)
            
        # Upload item
        table.put_item(Item=tableItem)
    return 'Successfully processed {} records.'.format(len(event['Records']))

