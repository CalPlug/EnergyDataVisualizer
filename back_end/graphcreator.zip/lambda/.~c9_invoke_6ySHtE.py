#from base64 import b64decode, b64encode
import json
import logging
import sys
import os
import base64
import datetime
import hashlib
import hmac 
import requests
import urllib.parse
import io

import matplotlib
matplotlib.use('AGG')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe

# ************* REQUEST VALUES *************
ES_ENDPOINT = 'https://search-sensordata-6xony62c6ndp7be6j7hxv5e37m.us-east-1.es.amazonaws.com/sensor-data/_search'
ES_ENDPOINT_OBJ = urllib.parse.urlparse(ES_ENDPOINT)
METHOD = 'GET'
SERVICE = 'es'
HOST = ES_ENDPOINT_OBJ.netloc
CANONICAL_URI = ES_ENDPOINT_OBJ.path
REGION = os.environ.get('AWS_REGION')
endpoint = ES_ENDPOINT
# Read AWS access key from env. variables or configuration file.
ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
SECURITY_TOKEN = os.environ.get('AWS_SECURITY_TOKEN')

logging.basicConfig(level=logging.INFO)
log = logging.getLogger()
log.setLevel(logging.INFO)
s = requests.Session() # Start connection pool
log.info('Loading function')

# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning

def lambda_handler(event, context):
    log.info(event)
    # Create a date for headers and the credential string
    t = datetime.datetime.utcnow()
    amzdate = t.strftime('%Y%m%dT%H%M%SZ')
    datestamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    
    uid = event['uid']
    # request_parameters = urllib.parse.urlencode({'q': 'uid:'+ uid, 'sort':'timestamp:desc'})
    requesttseuqer    
    # Construct payload
    payload = {'query':dict()}
    # Query by uid
    payload['query']['term'] = {'uid' : uid}
    # Look for only last 24 hours
    payload['query']['range']['timestamp']['gte'] = 'now-1d/h'
    payload['sort'] = [{'timestamp': {'sort': 'desc'}]
    payloadString = json.dumps(payload)
    # Ask Elasticsearch for data
    # ************* CREATE A CANONICAL REQUEST *************
    # http://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html 
    canonical_querystring = request_parameters
    canonical_headers = 'host:{}\nx-amz-date:{}\n'.format(HOST, amzdate)
    SIGNED_HEADERS = 'host;x-amz-date'
    payload_hash = hashlib.sha256(payloadString.encode('utf-8')).hexdigest()
    canonical_request = '\n'.join([METHOD, CANONICAL_URI, canonical_querystring, 
                                    canonical_headers, SIGNED_HEADERS, payload_hash])
    log.info(json.dumps(canonical_request))
    ALGORITHM = 'AWS4-HMAC-SHA256'
    credential_scope = '{}/{}/{}/aws4_request'.format(datestamp, REGION, SERVICE)
    string_to_sign = '\n'.join([ALGORITHM, amzdate, credential_scope,
                        hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()])
    signing_key = getSignatureKey(SECRET_KEY, datestamp, REGION, SERVICE)
    signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()
    authorization_header = '{} Credential={}/{},SignedHeaders={},Signature={}'.format(
        ALGORITHM, ACCESS_KEY, credential_scope, SIGNED_HEADERS, signature)
    headers = {'x-amz-date':amzdate, 'Authorization':authorization_header, 'x-amz-security-token':SECURITY_TOKEN}
    
    # # ************* SEND THE REQUEST *************
    request_url = endpoint
    log.info("Requesting sensor data from url: {}".format(request_url))
    esResponse = s.request(method='get', url=request_url, json=payload)
    esPayload = esResponse.json()
    log.info("Elasticsearch payload: {}".format(esPayload))
    esResponse.raise_for_status()
    
    instantDemand = [data['_source']['InstantaneousDemand'] for data in esPayload['hits']['hits']]
    plt.clf()
    plt.xlabel('Last 24 hours')
    plt.xticks([])
    plt.ylabel('Instantaneous Demand')
    plt.plot(instantDemand, color='#7CFC00', path_effects=[pe.Stroke(linewidth=3, foreground='k'), pe.Normal()])
    # Save figure to memory
    f = io.BytesIO()
    plt.savefig(f,transparent=True, format='png')
    figureBytes = f.getvalue()
    
    # Base64 encode image and convert to string for API Gateway
    img_b64 = base64.b64encode(figureBytes)
    img_out = img_b64.decode('utf-8')
    return img_out