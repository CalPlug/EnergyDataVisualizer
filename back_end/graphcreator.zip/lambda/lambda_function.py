import json
import logging
import sys
import os
import base64
import datetime
import hashlib
import hmac 
import requests
import urllib.parse
import io
import copy
import matplotlib
import boto3
matplotlib.use('AGG')
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import numpy as np
from botocore.exceptions import ClientError
from matplotlib import rcParams
rcParams['font.family'] = 'monospace'


# ************* DynamoDB *************
TABLE_NAME = 'SensorMetaDeta'
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(TABLE_NAME)
# ************* REQUEST VALUES *************
ES_ENDPOINT = os.environ['ES_ENDPOINT']
ES_ENDPOINT_OBJ = urllib.parse.urlparse(ES_ENDPOINT)
METHOD = 'GET'
SERVICE = 'es'
HOST = ES_ENDPOINT_OBJ.netloc
CANONICAL_URI = ES_ENDPOINT_OBJ.path
REGION = os.environ.get('AWS_REGION')
endpoint = ES_ENDPOINT
# Read AWS access key from env. variables or configuration file.
ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')



# ************ PLOT VALUES ****************
LABEL_EFFECTS = {
    'size': 20,
    'color':'#FFFFFF', 
    'path_effects':[pe.Stroke(linewidth=2, foreground='black'), pe.Normal()]
}
TEXT_EFFECTS = {
    'size': 10,
    'color':'#FFFFFF', 
    'path_effects':[pe.Stroke(linewidth=1.5, foreground='black'), pe.Normal()],
}
SPINE_EFFECTS = [pe.Stroke(linewidth=2, foreground='black'), pe.Normal()]

PAYLOAD_FORMAT = {
    'size': 500,
    'query': {
        'bool': {'must': []}
    },
    'sort': [{'timestamp': 'asc'}]
}

# Set logger
logging.basicConfig(level=logging.INFO)
log = logging.getLogger()
log.setLevel(logging.INFO)
s = requests.Session() # Start connection pool
log.info('Loading function')

# Global figure
figure = plt.figure(figsize=(8, 6), dpi=100)

# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning
    
def requestES(payload, request_parameters):
    # ************* CREATE A CANONICAL REQUEST *************
    # http://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html 
    t = datetime.datetime.utcnow()
    amzdate = t.strftime('%Y%m%dT%H%M%SZ')
    datestamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    canonical_querystring = request_parameters
    canonical_headers = 'host:{}\nx-amz-date:{}\n'.format(HOST, amzdate)
    SIGNED_HEADERS = 'host;x-amz-date'
    payload_hash = hashlib.sha256(payload.encode('utf-8')).hexdigest()
    canonical_request = '\n'.join([METHOD, CANONICAL_URI, canonical_querystring, 
                                    canonical_headers, SIGNED_HEADERS, payload_hash])
    log.info(json.dumps(canonical_request))
    ALGORITHM = 'AWS4-HMAC-SHA256'
    credential_scope = '{}/{}/{}/aws4_request'.format(datestamp, REGION, SERVICE)
    string_to_sign = '\n'.join([ALGORITHM, amzdate, credential_scope,
                        hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()])
    SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
    signing_key = getSignatureKey(SECRET_KEY, datestamp, REGION, SERVICE)
    signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()
    authorization_header = '{} Credential={}/{},SignedHeaders={},Signature={}'.format(
        ALGORITHM, ACCESS_KEY, credential_scope, SIGNED_HEADERS, signature)
    headers = {'x-amz-date':amzdate, 'Authorization':authorization_header, 'x-amz-security-token': os.environ.get('AWS_SECURITY_TOKEN')}
    request_url = endpoint
    log.info("Requesting sensor data from url: {}".format(request_url))
    return s.request(method='get', url=request_url, json=json.loads(payload), headers=headers)
    
def lambda_handler(event, context):
    log.info(event)

    uid = event['uid']
    
    # Construct payload
    payload = copy.deepcopy(PAYLOAD_FORMAT)
    
    # Query elasticsearch by uid
    payload['query']['bool']['must'].append({'term' : {'uid' : uid}})
    # Look for only last 24 hours
    # payload['query']['bool']['must'].append({'range':{'timestamp':{'gte': 'now-1d/h'}}})
    payloadString = json.dumps(payload)
    esResponse = requestES(payloadString, '')
    esPayload = esResponse.json()
    log.info("Elasticsearch payload: {}".format(esPayload))
    esResponse.raise_for_status()
    
    
    plt.clf()
    
    
    values = [data['_source']['InstantaneousDemand'] for data in esPayload['hits']['hits']]
    ylabel = 'Instantaneous Demand (W)'
    try:
        response = table.get_item(Key={'uid': uid})
    except ClientError as e:
        log.error(e.response['Error']['Message'])
    else:
        if 'Item' in response:
            item = response['Item']
            log.info('Found metadata for uid({}) item: {}'.format(uid, str(item)))
            plt.suptitle(item['name'], **LABEL_EFFECTS)
            
            try:
                attribute = item['attribute']
                values = [data['_source'][attribute] for data in esPayload['hits']['hits']]
                ylabel = attribute + '(' + item['unit'] + ')'
            except Exception as e:
                log.error(e)    
            try:
                metadataJson = json.loads(item['data'])
            except:
                log.error('Invalid JSON string ' + item['data'])
            else:
                metadataText = '\n'.join(['{:<25s}: {:<15s}'.format(key,str(value)) for key,value in metadataJson.items()])
                plt.subplots_adjust(bottom=0.25)
                plt.gcf().text(0.1, 0.01, metadataText, fontsize=14,wrap=False)
        else:
            log.info('No metadata for uid: ' + uid)
            attribute = 'InstantaneousDemand'
    
    plt.ylabel(ylabel, **LABEL_EFFECTS)
    # TODO: Actually plot vlaues accurately. For now, we plot all data (mock data)
    plt.plot(np.linspace(0,24,len(values)), values, color='#7CFC00', path_effects=[pe.Stroke(linewidth=3, foreground='k'), pe.Normal()])
    plt.xlabel('Hours Ago', **LABEL_EFFECTS)
    plt.xticks(range(25), [str(i) for i in range(24, -1, -1)])
    
    # Save figure to memory
    f = io.BytesIO()
    plt.savefig(f, transparent=True, format='png')
    figureBytes = f.getvalue()
    
    # Base64 encode image and convert to string for API Gateway
    img_b64 = base64.b64encode(figureBytes)
    img_out = img_b64.decode('utf-8')
    return img_out