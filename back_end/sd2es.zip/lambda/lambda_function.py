import hashlib
import json
import logging
import os
import base64
import datetime
import hmac 
import requests
import urllib.parse
import io

ES_ENDPOINT = os.environ['ES_ENDPOINT']
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.info("Loading function")

# ************* REQUEST VALUES *************
ES_ENDPOINT_OBJ = urllib.parse.urlparse(ES_ENDPOINT)
METHOD = 'POST'
SERVICE = 'es'
HOST = ES_ENDPOINT_OBJ.netloc
CANONICAL_URI = ES_ENDPOINT_OBJ.path
REGION = os.environ.get('AWS_REGION')
endpoint = ES_ENDPOINT


logging.basicConfig(level=logging.INFO)
log = logging.getLogger()
log.setLevel(logging.INFO)

log.info('Loading function')
s = requests.Session() # Start connection pool
logger.info('Established client connection.')

# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning

def lambda_handler(event, context):
    log.info(event)
    # Create payload
    payloadFile = io.StringIO()
    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        logger.info("Decoded payload: " + payload)
        # Convert payload to JSON object
        payloadJson = json.loads(payload)
        # Create _id for elasticsearch
        # Create hash from sensor uid and timestamp
        sensorHash = hashlib.md5()
        sensorHash.update(payloadJson['uid'].encode('utf-8'))
        sensorHash.update(payloadJson['timestamp'].encode('utf-8'))
        # INDEX elasticsearch action { "index": { "_index": "website", "_type": "blog", "_id": "123" }}
        action = {'index': { '_index':'sensor-data', '_type': 'sensordatamodel', '_id': sensorHash.hexdigest()}}
        # Add action and corresponding payload to stringbuffer
        print(json.dumps(action), file=payloadFile)
        print(payload, file=payloadFile)
    payload = payloadFile.getvalue()
    log.info("Payload format: {}".format(payload))
    
    # ************* CREATE A CANONICAL REQUEST *************    
    # Create a date for headers and the credential string
    t = datetime.datetime.utcnow()
    amzdate = t.strftime('%Y%m%dT%H%M%SZ')
    datestamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    
    # http://docs.aws.amazon.com/general/latest/gr/sigv4-create-canonical-request.html 
	# Read AWS access key from env. variables or configuration file.
	ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')
	SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
    request_parameters = ''
    canonical_querystring = request_parameters
    canonical_headers = 'host:' + HOST + '\n' + 'x-amz-date:' + amzdate + '\n'
    SIGNED_HEADERS = 'host;x-amz-date'
    payload_hash = hashlib.sha256(payload.encode('utf-8')).hexdigest()
    canonical_request = METHOD + '\n' + CANONICAL_URI + '\n' + canonical_querystring + '\n' + canonical_headers + '\n' + SIGNED_HEADERS + '\n' + payload_hash
    log.info(canonical_request)
    ALGORITHM = 'AWS4-HMAC-SHA256'
    credential_scope = datestamp + '/' + REGION + '/' + SERVICE + '/' + 'aws4_request'
    string_to_sign = ALGORITHM + '\n' +  amzdate + '\n' +  credential_scope + '\n' +  \
                        hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
    signing_key = getSignatureKey(SECRET_KEY, datestamp, REGION, SERVICE)
    signature = hmac.new(signing_key, (string_to_sign).encode('utf-8'), hashlib.sha256).hexdigest()
    authorization_header = ALGORITHM + ' ' + 'Credential=' + ACCESS_KEY + '/' + credential_scope + ', ' + \
                            'SignedHeaders=' + SIGNED_HEADERS + ', ' + 'Signature=' + signature
    SECURITY_TOKEN = os.environ.get('AWS_SECURITY_TOKEN')
    headers = {'x-amz-date':amzdate, 'Authorization':authorization_header, 'x-amz-security-token':SECURITY_TOKEN}

    # # ************* SEND THE REQUEST *************
    post_url = endpoint
    log.info("POST sensor data to url: {}".format(post_url))
    esResponse = s.post(post_url, headers=headers, data=payload)
    esPayload = esResponse.json()
    log.info("Elasticsearch payload: {}".format(esPayload))
    esResponse.raise_for_status()
    return 'Successfully processed {} records.'.format(len(event['Records']))
